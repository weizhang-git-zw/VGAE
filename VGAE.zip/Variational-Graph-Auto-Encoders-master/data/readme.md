These are the training data, including two files which represent two relationship graphs: 'paper citation' and 'facebook friendship'.

Both the file save all the 'nodes pairs' in the graph, which means an edge connects two nodes.
