Result: the ROC curves of our model training on two dataset.
